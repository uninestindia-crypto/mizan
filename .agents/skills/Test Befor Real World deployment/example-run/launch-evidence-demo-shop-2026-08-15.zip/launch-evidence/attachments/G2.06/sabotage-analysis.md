# G2.06 Sabotage Analysis — demo-shop v1.0.0

Baseline: 4 tests, all green (recorded).

| # | Sabotage | Suite result | Verdict |
|---|---|---|---|
| 1 | `lineTotal`: `unitPrice * quantity` -> `unitPrice + quantity` | RED (1 failure) | Caught |
| 2 | `withTax`: `Math.round(...)` -> `Math.floor(...)` | **GREEN** | **NOT CAUGHT** |
| 3 | `applyDiscount`: returns `total` unchanged | RED (1 failure) | Caught |

## Finding — sabotage 2 survived

The tax-rounding rule has no test asserting on it. `cartTotal([{price:100,qty:1}], 0.1, 0)`
returns exactly 110 under both `Math.round` and `Math.floor`, so the only test touching this
function cannot distinguish correct rounding from incorrect rounding.

Line coverage reports this function as 100% covered. Coverage is measuring execution, not
assertion.

**Impact:** every order whose pre-tax total produces a fractional third decimal is under-charged
by up to one cent, silently, and the discrepancy accumulates in reconciliation.

**Required fix:** add cases at the rounding boundary in both directions
(e.g. 0.615 -> 0.62, 0.614 -> 0.61), then re-run sabotage 2 and confirm it goes red.
