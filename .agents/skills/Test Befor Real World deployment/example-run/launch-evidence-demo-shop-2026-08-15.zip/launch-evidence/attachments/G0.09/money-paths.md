# demo-shop v1.0.0 — Critical Paths (G0.09)

1. **Browse -> add to cart -> checkout -> receipt.** Money moves. Involves `pricing.cartTotal`,
   the Stripe charge, and the order write. If this silently returns a wrong number, customers are
   over- or under-charged and we find out at reconciliation.
2. **Order lookup by id.** `orders.getOrderById`. Reads customer data. If authorization is wrong
   here, one customer sees another's order.
3. **Cancel order -> refund issued.** `orders.cancelOrder`. Money moves outward and the operation
   is not currently idempotent.

Not critical: catalogue browsing without a cart, the static marketing pages.
